'use client';

import { ColumnDef } from "@tanstack/react-table";
import { MoreHorizontal, Pencil, Trash2 } from "lucide-react";
import { useState } from "react";

export type Transaction = {
  id: string;
  date: string;
  description: string;
  amount: number;
  type: 'gelir' | 'gider';
  category_id: string | null;
  category: { name: string; color: string } | null; // Supabase join ile gelir
};

type TransactionTableMeta = {
  onEdit: (row: Transaction) => void;
  onDelete: (id: string) => void;
};

function ActionsCell({ row, table }: { row: any; table: any }) {
  const [open, setOpen] = useState(false);
  const meta = table.options.meta as TransactionTableMeta | undefined;

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="p-2 hover:bg-slate-100 rounded-md transition-colors"
      >
        <MoreHorizontal className="w-4 h-4 text-slate-500" />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute right-0 mt-1 w-36 bg-white border border-slate-200 rounded-lg shadow-lg z-20">
            <button
              onClick={() => { meta?.onEdit(row.original); setOpen(false); }}
              className="w-full flex items-center gap-2 px-3 py-2 text-sm hover:bg-slate-50 text-slate-700"
            >
              <Pencil className="w-3.5 h-3.5" /> Düzenle
            </button>
            <button
              onClick={() => { meta?.onDelete(row.original.id); setOpen(false); }}
              className="w-full flex items-center gap-2 px-3 py-2 text-sm hover:bg-rose-50 text-rose-600"
            >
              <Trash2 className="w-3.5 h-3.5" /> Sil
            </button>
          </div>
        </>
      )}
    </div>
  );
}

export const columns: ColumnDef<Transaction>[] = [
  {
    accessorKey: "date",
    header: "Tarih",
    cell: ({ row }) => new Date(row.getValue("date")).toLocaleDateString("tr-TR"),
  },
  { accessorKey: "description", header: "Açıklama" },
  {
    accessorKey: "category",
    header: "Kategori",
    cell: ({ row }) => {
      const category = row.original.category;
      if (!category) return <span className="text-slate-400 text-sm">-</span>;
      return (
        <span
          className="px-2 py-1 rounded-full text-xs font-medium"
          style={{ backgroundColor: `${category.color}20`, color: category.color }}
        >
          {category.name}
        </span>
      );
    },
  },
  {
    accessorKey: "amount",
    header: "Tutar",
    cell: ({ row }) => {
      const amount = parseFloat(row.getValue("amount"));
      const type = row.original.type;
      const formatted = new Intl.NumberFormat("tr-TR", {
        style: "currency",
        currency: "TRY",
      }).format(amount);
      return (
        <div className={`font-medium ${type === 'gelir' ? 'text-emerald-600' : 'text-rose-600'}`}>
          {type === 'gelir' ? '+' : '-'}{formatted}
        </div>
      );
    },
  },
  {
    id: "actions",
    cell: ({ row, table }) => <ActionsCell row={row} table={table} />,
  },
];